package com.pranab.covid_19vaccination

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.recyclerview.widget.RecyclerView

class CenterRVAdapter(private val centerList: List<CenterRVModel>) :
    RecyclerView.Adapter<CenterRVAdapter.centerRVViewHolder>() {

    class centerRVViewHolder(itemView:View) :RecyclerView.ViewHolder(itemView){
        val centerNameTV :TextView =itemView.findViewById(R.id.idTVCenterName)
        val centerAddressTV :TextView =itemView.findViewById(R.id.idTVCenterLocation)
        val centerTimingsTV :TextView =itemView.findViewById(R.id.idTVCenterTimings)
        val vaccineNameTV :TextView =itemView.findViewById(R.id.idTVVaccineName)
        val vaccineFeesTV :TextView =itemView.findViewById(R.id.idTVVaccineFees)
        val ageLimitsTV :TextView =itemView.findViewById(R.id.idTVAgeLimits)
        val availabilityTV :TextView =itemView.findViewById(R.id.idTVAvailability)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): centerRVViewHolder {
        val itemView= LayoutInflater.from(parent.context).inflate(R.layout.center_rv_item,parent,false)
        return centerRVViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: centerRVViewHolder, position: Int) {
        val center =centerList[position]
        holder.centerNameTV.text=center.centerName
        holder.centerAddressTV.text=center.centerAddress
        holder.centerTimingsTV.text= (" From : " +center.centerFromTime + " To : "+center.centerToTime)
        holder.vaccineNameTV.text=center.VaccineName
        holder.vaccineFeesTV.text=center.fee_type
        holder.ageLimitsTV.text=("Age Limits : "+center.ageLimit.toString())
        holder.availabilityTV.text=("Availability : "+center.availiableCapacity.toString())
    }

    override fun getItemCount(): Int {
        return centerList.size
    }
}