package com.pranab.covid_19vaccination

import java.net.Inet4Address


data class CenterRVModel (
    val centerName : String,
    val centerAddress:String,
    val centerFromTime :String,
    val centerToTime : String,
    val fee_type :String,
    val ageLimit :Int,
    var VaccineName : String,
    val availiableCapacity :Int
    )

